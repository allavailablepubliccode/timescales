from pathlib import Path
import os
import numpy as np
import nibabel as nib

BASE = Path(os.environ.get('NARRATIVES_ROOT', Path.home() / 'Desktop/narratives')).expanduser()
ROOT = BASE / 'derivatives/fmriprep'
OUT = Path(os.environ.get('RECONSTRUCTION_DIR', BASE / 'reconstruction')).expanduser()
OUT.mkdir(parents=True, exist_ok=True)
SUBJECTS=['034','066','106','111','132','133','134','139','140','142','144','199','268','326','327','328','330','331','334','335','337','340','341','344']
TASKS=['notthefallintact','notthefalllongscram']; CROP_N=3
common_mask=None; reference_img=None
for sub in SUBJECTS:
 for task in TASKS:
  f=ROOT/f'sub-{sub}/func/sub-{sub}_task-{task}_space-MNI152NLin2009cAsym_res-native_desc-brain_mask.nii.gz'
  if not f.exists(): raise FileNotFoundError(f)
  img=nib.load(f); m=np.asarray(img.dataobj)>0
  if common_mask is None: common_mask=m.copy(); reference_img=img
  else: common_mask &= m
n_vox=int(common_mask.sum()); print('Common-mask voxels:',n_vox)
nib.save(nib.Nifti1Image(common_mask.astype(np.uint8),reference_img.affine,reference_img.header),OUT/'common_brain_mask_48runs.nii.gz')
for sub in SUBJECTS:
 for task in TASKS:
  f=ROOT/f'sub-{sub}/func/sub-{sub}_task-{task}_space-MNI152NLin2009cAsym_res-native_desc-preproc_bold.nii.gz'
  if not f.exists(): raise FileNotFoundError(f)
  img=nib.load(f); data=np.asarray(img.dataobj,dtype=np.float32)[...,CROP_N:]
  ts=data[common_mask,:].T; np.save(OUT/f'sub-{sub}_{task}_raw_masked.npy',ts)
  print(sub,task,ts.shape)
print('Expected final common-mask voxels: 45,083; observed:',n_vox)
