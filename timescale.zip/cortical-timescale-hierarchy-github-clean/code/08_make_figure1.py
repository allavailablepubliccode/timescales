import numpy as np, matplotlib.pyplot as plt
from pathlib import Path
from importlib.machinery import SourceFileLoader
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent
m=SourceFileLoader('model',str(HERE/'07_model_predictions.py')).load_module()
t=np.linspace(4.2,11.2,141); a=np.linspace(0,2,101); r0=np.array([m.ratio(x,0) for x in t]); R=np.array([[m.ratio(x,y) for x in t] for y in a])
fig,(ax,bx)=plt.subplots(1,2,figsize=(10,4.2),constrained_layout=True)
ax.axhspan(m.LO,m.HI,alpha=.18); ax.plot(t,r0,lw=2); ax.axhline(m.EMP,ls='--',lw=1.5); ax.set(xlabel='max. scrambled integration timescale (s)',ylabel='intact-to-scrambled variance ratio',xlim=(4.2,11.2)); ax.text(.02,.96,'A',transform=ax.transAxes,va='top',fontweight='bold')
mesh=bx.pcolormesh(t,a,R,shading='auto'); bx.contour(t,a,R,levels=[m.EMP],colors='white',linewidths=1.6); bx.contour(t,a,R,levels=[m.HI],colors='white',linestyles='--',linewidths=1.6); bx.set(xlabel='max. scrambled integration timescale (s)',ylabel=r'spectral exponent ($\alpha$)',xlim=(4.2,11.2),ylim=(0,2)); bx.text(.02,.96,'B',transform=bx.transAxes,va='top',fontweight='bold',color='white'); fig.colorbar(mesh,ax=bx,label='predicted ratio')
for ext in ('pdf','png','svg'): fig.savefig(ROOT/'figures'/f'Figure_1_reproduced.{ext}',dpi=300)
print('Saved reproduced Figure 1 in PDF/PNG/SVG')
