import numpy as np
from pathlib import Path
TAU_MIN=.05; TAU_INT=45.; W0=2*np.pi/128; W1=2*np.pi*.1
EMP=1.1688880566702915; LO=1.04185081; HI=1.30510725

def G(tm,a,n=3000):
 D=np.log(tm/TAU_MIN); u=np.logspace(np.log10(W0*TAU_MIN),np.log10(W1*TAU_MIN),n)
 x=.5*np.log(np.exp(2*D)*(1+u*u)/(1+u*u*np.exp(2*D)))
 y=np.arctan(u*np.exp(D))-np.arctan(u)
 return np.trapezoid(u**(-a)*(x*x+y*y)*u,np.log(u))
def ratio(t,a): return G(TAU_INT,a)/G(t,a)
if __name__=='__main__':
 for t in (4.2,7.7,11.2): print(f'tau_scr={t:.1f}, alpha=0: {ratio(t,0):.10f}')
 taus=np.linspace(4.2,11.2,141); alphas=np.linspace(0,2,101); R=np.array([[ratio(t,a) for t in taus] for a in alphas]); pct=100*np.mean((R>=LO)&(R<=HI)); print(f'Uniform displayed-grid agreement: {pct:.3f}% ({R.size} grid points)')
 out=Path(__file__).resolve().parents[1]/'results'/'model_surface.npz'; np.savez(out,taus=taus,alphas=alphas,ratio=R,empirical=EMP,ci=np.array([LO,HI])); print('Saved',out)
