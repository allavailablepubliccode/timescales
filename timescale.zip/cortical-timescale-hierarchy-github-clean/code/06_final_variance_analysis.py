from pathlib import Path
import numpy as np

import os
BASE = Path(os.environ.get('NARRATIVES_ROOT', Path.home() / 'Desktop/narratives')).expanduser()
ROOT = Path(os.environ.get('RECONSTRUCTION_DIR', BASE / 'reconstruction')).expanduser()

SUBJECTS = [
    "034","066","106","111","132","133","134","139","140","142","144","199",
    "268","326","327","328","330","331","334","335","337","340","341","344"
]

INTACT = "notthefallintact"
SCRAM  = "notthefalllongscram"

N_BOOT = 10000
N_PERM = 100000
SEED = 42

mask = np.load(ROOT / "final_shared_isc_mask.npy").astype(bool)

print(f"Frozen ISC mask: {mask.sum():,} voxels")
print(f"Participants: {len(SUBJECTS)}")

def pc1_variance(path):
    """
    Historical analysis architecture:
    voxelwise z-score across time, then PCA separately for
    each participant and condition.

    PC1 score variance equals the largest eigenvalue of the
    sample covariance matrix.
    """
    x = np.load(path).astype(np.float64)
    x = x[:, mask]

    # MATLAB zscore default: sample SD (N-1)
    mu = x.mean(axis=0)
    sd = x.std(axis=0, ddof=1)

    good = np.isfinite(sd) & (sd > 0)
    x = x[:, good]

    x = (x - mu[:, None] if False else x)  # no-op; clarity below
    x = (x - x.mean(axis=0)) / x.std(axis=0, ddof=1)

    # Largest singular value is sufficient for PC1 variance.
    s1 = np.linalg.svd(
        x,
        full_matrices=False,
        compute_uv=False
    )[0]

    return s1**2 / (x.shape[0] - 1)


var_i = []
var_s = []

print("\nComputing participant variances...")

for sub in SUBJECTS:
    vi = pc1_variance(
        ROOT / f"sub-{sub}_{INTACT}_raw_masked.npy"
    )
    vs = pc1_variance(
        ROOT / f"sub-{sub}_{SCRAM}_raw_masked.npy"
    )

    var_i.append(vi)
    var_s.append(vs)

    print(
        f"sub-{sub}: "
        f"I={vi:.6f}  S={vs:.6f}  ratio={vi/vs:.6f}"
    )

var_i = np.asarray(var_i)
var_s = np.asarray(var_s)
ratio = var_i / var_s
log_ratio = np.log(ratio)

gm = np.exp(log_ratio.mean())

# ------------------------------------------------------------
# Bootstrap participants: geometric-mean ratio
# ------------------------------------------------------------

rng = np.random.default_rng(SEED)

boot = np.empty(N_BOOT)

for b in range(N_BOOT):
    idx = rng.integers(0, len(SUBJECTS), len(SUBJECTS))
    boot[b] = np.exp(log_ratio[idx].mean())

ci_lo, ci_hi = np.percentile(boot, [2.5, 97.5])

# ------------------------------------------------------------
# Paired sign-flip permutation test on raw variance difference
# H1: intact > scrambled
# ------------------------------------------------------------

diff = var_i - var_s
obs_diff = diff.mean()

perm = np.empty(N_PERM)

for b in range(N_PERM):
    signs = rng.choice((-1.0, 1.0), size=len(diff))
    perm[b] = np.mean(diff * signs)

p_perm = (np.sum(perm >= obs_diff) + 1) / (N_PERM + 1)

# ------------------------------------------------------------
# One-sample t-test of log ratios
# ------------------------------------------------------------

from scipy.stats import ttest_1samp, binomtest

tt = ttest_1samp(log_ratio, 0.0, alternative="greater")

n_gt1 = int(np.sum(ratio > 1))

bt = binomtest(
    n_gt1,
    n=len(ratio),
    p=0.5,
    alternative="greater"
)

# ------------------------------------------------------------
# Descriptive means / SEM
# ------------------------------------------------------------

sem_i = var_i.std(ddof=1) / np.sqrt(len(var_i))
sem_s = var_s.std(ddof=1) / np.sqrt(len(var_s))

print("\n========================================")
print("DEFINITIVE EMPIRICAL RESULTS")
print("========================================")

print(f"Intact variance mean ± SEM:   {var_i.mean():.6f} ± {sem_i:.6f}")
print(f"Scrambled variance mean ± SEM:{var_s.mean():.6f} ± {sem_s:.6f}")

print(f"\nGeometric mean ratio: {gm:.6f}")
print(f"Bootstrap 95% CI:     {ci_lo:.6f} – {ci_hi:.6f}")

print(f"\nParticipants ratio > 1: {n_gt1}/{len(ratio)}")
print(f"Binomial p:             {bt.pvalue:.8g}")

print(f"\nMean-difference sign-flip p: {p_perm:.8g}")

print(
    f"Log-ratio t-test: "
    f"t({len(ratio)-1})={tt.statistic:.6f}, "
    f"p={tt.pvalue:.8g}"
)

print("\nRatios:")
for sub, r in zip(SUBJECTS, ratio):
    print(f"{sub}  {r:.6f}")

np.savez(
    ROOT / "final_variance_results.npz",
    subjects=np.asarray(SUBJECTS),
    intact_variance=var_i,
    scrambled_variance=var_s,
    ratio=ratio,
    geometric_mean=gm,
    bootstrap_ci=np.asarray([ci_lo, ci_hi]),
    bootstrap_distribution=boot,
    permutation_p=p_perm,
    t_statistic=tt.statistic,
    t_p=tt.pvalue,
    n_ratio_gt_1=n_gt1,
    binomial_p=bt.pvalue,
)

print(
    "\nSaved:",
    ROOT / "final_variance_results.npz"
)
