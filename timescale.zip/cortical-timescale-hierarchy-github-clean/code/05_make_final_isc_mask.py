from pathlib import Path
import numpy as np
import nibabel as nib

import os
BASE = Path(os.environ.get('NARRATIVES_ROOT', Path.home() / 'Desktop/narratives')).expanduser()
ROOT = Path(os.environ.get('RECONSTRUCTION_DIR', BASE / 'reconstruction')).expanduser()

TASKS = [
    "notthefallintact",
    "notthefalllongscram",
]

N_PERM = 10000
Q = 0.05
SEED = 42

def bh_fdr(p, q=0.05):
    """Benjamini-Hochberg FDR; returns boolean rejection mask."""
    p = np.asarray(p)
    finite = np.isfinite(p)

    pf = p[finite]
    order = np.argsort(pf)
    ranked = pf[order]

    thresholds = q * np.arange(1, len(ranked) + 1) / len(ranked)
    passed = ranked <= thresholds

    reject_f = np.zeros(len(pf), dtype=bool)

    if np.any(passed):
        k = np.where(passed)[0][-1]
        cutoff = ranked[k]
        reject_f = pf <= cutoff
        print(f"  BH cutoff p = {cutoff:.8g}")
    else:
        print("  No voxels survive FDR")

    reject = np.zeros(p.shape, dtype=bool)
    reject[finite] = reject_f
    return reject


rng = np.random.default_rng(SEED)

# Load the 48-run common brain mask used to define voxel indexing
brain_img = nib.load(ROOT / "common_brain_mask_48runs.nii.gz")
brain = np.asarray(brain_img.dataobj) > 0
nvox = int(brain.sum())

print(f"Brain-mask voxels: {nvox:,}")
print(f"Permutations: {N_PERM:,}")
print(f"FDR q: {Q}")

sig_masks = {}

for task in TASKS:
    print(f"\n=== {task} ===")

    r = np.load(ROOT / f"{task}_loo_isc_subjects.npy").astype(np.float64)

    if r.shape[1] != nvox:
        raise RuntimeError(
            f"{task}: ISC has {r.shape[1]} voxels but brain mask has {nvox}"
        )

    # Fisher transform, clipping numerical endpoints
    z = np.arctanh(np.clip(r, -0.999999, 0.999999))

    # Observed mean Fisher-z ISC
    obs = z.mean(axis=0)

    # One-sided sign-flip permutation test:
    # H1 = mean Fisher-z ISC > 0
    exceed = np.zeros(nvox, dtype=np.int32)

    for b in range(N_PERM):
        signs = rng.choice((-1.0, 1.0), size=(z.shape[0], 1))
        null = (z * signs).mean(axis=0)
        exceed += null >= obs

        if (b + 1) % 1000 == 0:
            print(f"  permutation {b+1:,}/{N_PERM:,}")

    # +1 correction
    p = (exceed + 1.0) / (N_PERM + 1.0)

    sig = bh_fdr(p, Q)
    sig_masks[task] = sig

    print(f"  Significant voxels: {sig.sum():,} / {nvox:,}")

    np.save(ROOT / f"{task}_isc_p_signflip.npy", p)
    np.save(ROOT / f"{task}_isc_fdr_mask.npy", sig)

    vol = np.zeros(brain.shape, dtype=np.uint8)
    vol[brain] = sig.astype(np.uint8)

    nib.save(
        nib.Nifti1Image(vol, brain_img.affine, brain_img.header),
        ROOT / f"{task}_isc_fdr_mask.nii.gz"
    )

# Shared-response mask = significant in EITHER condition
final = sig_masks[TASKS[0]] | sig_masks[TASKS[1]]

print("\n=== FINAL MASK ===")
print(f"Union significant voxels: {final.sum():,} / {nvox:,}")

np.save(ROOT / "final_shared_isc_mask.npy", final)

vol = np.zeros(brain.shape, dtype=np.uint8)
vol[brain] = final.astype(np.uint8)

out = ROOT / "final_shared_isc_mask.nii.gz"

nib.save(
    nib.Nifti1Image(vol, brain_img.affine, brain_img.header),
    out
)

print("Saved:", out)
