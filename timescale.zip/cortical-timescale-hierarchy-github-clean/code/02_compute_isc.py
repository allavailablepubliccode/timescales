from pathlib import Path
import os, numpy as np, nibabel as nib
BASE=Path(os.environ.get('NARRATIVES_ROOT',Path.home()/'Desktop/narratives')).expanduser(); DATA=Path(os.environ.get('RECONSTRUCTION_DIR',BASE/'reconstruction')).expanduser()
SUBJECTS=['034','066','106','111','132','133','134','139','140','142','144','199','268','326','327','328','330','331','334','335','337','340','341','344']; TASKS=['notthefallintact','notthefalllongscram']
mask_img=nib.load(DATA/'common_brain_mask_48runs.nii.gz'); mask=np.asarray(mask_img.dataobj)>0; n_vox=int(mask.sum())
for task in TASKS:
 runs=[]
 for sub in SUBJECTS:
  x=np.load(DATA/f'sub-{sub}_{task}_raw_masked.npy').astype(np.float32); mean=x.mean(0); sd=x.std(0,ddof=1); good=np.isfinite(sd)&(sd>0); z=np.zeros_like(x); z[:,good]=(x[:,good]-mean[good])/sd[good]; runs.append(z)
 X=np.stack(runs); group_sum=np.sum(X,axis=0,dtype=np.float64); isc=np.empty((len(SUBJECTS),n_vox),np.float32)
 for i in range(len(SUBJECTS)):
  A=X[i].astype(np.float64); B=(group_sum-X[i])/(len(SUBJECTS)-1); A-=A.mean(0); B-=B.mean(0); num=np.sum(A*B,0); den=np.sqrt(np.sum(A*A,0)*np.sum(B*B,0)); r=np.zeros(n_vox); valid=den>0; r[valid]=num[valid]/den[valid]; isc[i]=np.clip(r,-.999999,.999999)
 fisher=np.arctanh(isc.astype(np.float64)); group_r=np.tanh(fisher.mean(0)); np.save(DATA/f'{task}_loo_isc_subjects.npy',isc); np.save(DATA/f'{task}_loo_isc_group_r.npy',group_r)
 vol=np.zeros(mask.shape,np.float32); vol[mask]=group_r.astype(np.float32); nib.save(nib.Nifti1Image(vol,mask_img.affine,mask_img.header),DATA/f'{task}_loo_isc_group_r.nii.gz')
 print(task,'mean',group_r.mean(),'median',np.median(group_r),'positive',np.sum(group_r>0))
