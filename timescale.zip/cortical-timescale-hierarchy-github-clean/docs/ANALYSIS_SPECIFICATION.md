# Frozen analysis specification

This is the permanent record of the empirical and model analysis used for **A Scale-Free Model of the Cortical Timescale Hierarchy During Narrative Comprehension** (Fagerholm, Brázdil, Chang). It records the exact public-data provenance, cohort, analysis stages, statistical procedures, model parameters, and expected outputs required to reproduce the manuscript results.

## Dataset provenance

Public dataset: Hasson Lab **Narratives** DataLad dataset (Nastase et al., 2021).

- DataLad source: `https://datasets.datalad.org/labs/hasson/narratives`
- Parent Narratives commit used: `6c066679613024cb53906252d5c35d14b9fc8cbd`
- fMRIPrep subdataset: `derivatives/fmriprep`
- fMRIPrep commit used: `b6435a9e4445b971be717d059d4a398d64a42354`
- The parent commit records `derivatives/fmriprep` at exactly `b6435a9e4445b971be717d059d4a398d64a42354`.
- Local DataLad version when provenance was recorded: 1.7.1.
- Local git-annex version when provenance was recorded: 10.20261006.

The final analysis used fMRIPrep outputs only. Raw/public data are **not redistributed** here.

## Exact cohort and conditions

24 participants: sub-034, sub-066, sub-106, sub-111, sub-132, sub-133, sub-134, sub-139, sub-140, sub-142, sub-144, sub-199, sub-268, sub-326, sub-327, sub-328, sub-330, sub-331, sub-334, sub-335, sub-337, sub-340, sub-341, sub-344.

Tasks: `notthefallintact` and `notthefalllongscram` (48 runs total).

Exact file templates consumed by `01_prepare_notthefall.py`:

- BOLD: `derivatives/fmriprep/sub-<ID>/func/sub-<ID>_task-<TASK>_space-MNI152NLin2009cAsym_res-native_desc-preproc_bold.nii.gz`
- mask: `derivatives/fmriprep/sub-<ID>/func/sub-<ID>_task-<TASK>_space-MNI152NLin2009cAsym_res-native_desc-brain_mask.nii.gz`

All 48 BOLD images used in the successful analysis had shape 65 x 77 x 49 x 400, voxel size 3 x 3 x 4 mm, and common geometry/affine. The first 3 volumes were removed, leaving 397 time points.

## Stage 1: common brain mask and extraction

`01_prepare_notthefall.py` intersects the 48 run-specific fMRIPrep brain masks. A voxel must be present in every run mask. The intersection contains **45,083 voxels** and is saved as `common_brain_mask_48runs.nii.gz`. Each BOLD run is cropped by 3 volumes and extracted inside this mask as a 397 x 45,083 time-by-voxel NumPy array. No temporal z-scoring occurs at this stage.

## Stage 2: leave-one-out ISC

`02_compute_isc.py` analyzes each condition separately. Within participant, each voxel time series is z-scored across time using sample SD (`ddof=1`). For each participant and voxel, that participant's time series is correlated with the mean of the other 23 participants. Subject-level correlations are Fisher-z transformed for group summaries. The participant-level r arrays are saved and are the input to mask inference.

## Stage 3: final shared-response mask

`05_make_final_isc_mask.py` Fisher-transforms participant LOO ISC values and tests mean Fisher-z ISC > 0 separately for each condition using subject-level sign flips.

- permutations: 10,000
- seed: 42
- one-sided alternative: mean Fisher-z ISC > 0
- p-value correction: +1 correction `(exceed+1)/(N_PERM+1)`
- multiple comparisons: Benjamini-Hochberg FDR, q=0.05, separately per condition

Frozen results:

- intact BH cutoff p = 0.02189781; 19,810 significant voxels
- long-scrambled BH cutoff p = 0.02669733; 24,113 significant voxels
- final mask = union of significant voxels in either condition
- final shared-response mask = **29,342 voxels**

The exact frozen NIfTI is `masks/final_shared_isc_mask.nii.gz`. It was frozen before the final variance result was inspected.

## Stage 4: final PC1 variance analysis

`06_final_variance_analysis.py` returns to the raw extracted arrays from Stage 1, applies the 29,342-voxel final mask, and z-scores each voxel across time using sample SD (`ddof=1`, matching MATLAB `zscore` default). PCA is performed **separately for every participant and every condition**. There is no common/group PCA basis. PC1 variance is the largest sample-covariance eigenvalue, computed as the squared largest singular value divided by `n_time-1`.

For participant j: `R_j = intact_PC1_variance / scrambled_PC1_variance`. Group effect is the geometric mean of the 24 ratios.

Frozen empirical results:

- intact mean +/- SEM = 5871.178633 +/- 370.109612
- scrambled mean +/- SEM = 4987.422423 +/- 306.807938
- geometric mean ratio = **1.1688880566702915**
- participant bootstrap: 10,000 resamples, seed 42
- 95% bootstrap CI = **1.04185081 to 1.30510725**
- 18/24 ratios > 1; one-sided binomial p = 0.011327922344207764
- paired raw-variance-difference sign-flip test: 100,000 permutations; one-sided p = 0.0062599374006259935
- one-sample one-sided t-test of log ratios against 0: t(23)=2.6720391347724792, p=0.00680722690058966

The original NPZ, including bootstrap distribution, is frozen under `results/final_variance_results.npz`; the participant values are also exported to CSV.

## Model and Figure 1

Fixed model quantities:

- tau_min = 0.05 s
- tau_max_intact = 45.0 s
- omega_min = 2*pi/128 rad/s
- omega_max = 2*pi*0.1 rad/s
- reference alpha = 0

Lerner et al. (2011) reported sentence durations 7.7 +/- 3.5 s. The displayed scrambled maximum-timescale interval is therefore the interval corresponding to that reported mean +/- SD: **4.2-11.2 s**. This is not a reported min-max range.

At alpha=0 the model gives approximately:

- tau_scr=4.2 s -> 1.2733773
- tau_scr=7.7 s -> 1.1282867
- tau_scr=11.2 s -> 1.0760825

Thus all alpha=0 predictions across 4.2-11.2 s fall within the empirical 95% CI. Figure 1B displays tau_scr=4.2-11.2 s and alpha=0-2. The lower empirical CI lies below all predictions in this displayed domain, so only the upper-CI contour appears. All parameter combinations below that upper-CI contour successfully reproduce the empirical ratio within its 95% CI.

`07_model_predictions.py` is the frozen numerical implementation used for the repository reproduction. On its documented uniform 141 x 101 displayed grid, 80.191% of parameter combinations lie within the empirical CI; the manuscript intentionally reports this as **approximately 80%** because the decimal depends on numerical grid discretization.

`figures/Figure_1.pdf` is the manuscript figure. `08_make_figure1.py` generates the figure from the same numerical model and empirical bounds; minor rendering details can vary with matplotlib version.


## Reproduction record

The scripts in `code/` implement the analysis described above and use the environment variables `NARRATIVES_ROOT` and `RECONSTRUCTION_DIR` so the pipeline can be run from any local dataset location. The frozen mask and numerical outputs included in the repository provide reference artifacts against which a fresh run can be checked.
